package org.example;

public class Student {
    private Course course;
    private String name;

    // Constructor Injection
    public Student(String name,Course course) {
        this.name =name;
        this.course = course;
    }

    public void displayCourse() {
        System.out.println("Student:"+name);
        course.displayCourse();
    }
}